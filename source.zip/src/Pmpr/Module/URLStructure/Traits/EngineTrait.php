<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708633897f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Traits; use Pmpr\Module\URLStructure\Engine; trait EngineTrait { protected ?Engine $engine = null; public function uykissogmuaaocsg() : Engine { if ($this->engine) { goto cecuyayqoioasumi; } $this->engine = Engine::symcgieuakksimmu(); cecuyayqoioasumi: return $this->engine; } }
