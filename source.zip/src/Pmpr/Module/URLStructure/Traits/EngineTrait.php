<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dda3ce3070e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Traits; use Pmpr\Module\URLStructure\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
