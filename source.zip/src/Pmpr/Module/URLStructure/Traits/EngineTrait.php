<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68daeb7a21c5a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Traits; use Pmpr\Module\URLStructure\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
