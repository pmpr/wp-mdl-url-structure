<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106baa2086             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Traits; use Pmpr\Module\URLStructure\Engine; trait EngineTrait { public function uykissogmuaaocsg() : Engine { return Engine::symcgieuakksimmu(); } }
