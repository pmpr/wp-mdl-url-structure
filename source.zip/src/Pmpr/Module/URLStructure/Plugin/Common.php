<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecd4b1873             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; use Pmpr\Module\URLStructure\Container; abstract class Common extends Container { }
