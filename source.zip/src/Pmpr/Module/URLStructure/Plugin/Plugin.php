<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11e9e8858             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; use Pmpr\Module\URLStructure\Container; class Plugin extends Container { public function mameiwsayuyquoeq() { Yoast::symcgieuakksimmu(); Woocommerce::symcgieuakksimmu(); } }
