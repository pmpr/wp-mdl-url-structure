<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708633897f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; use Pmpr\Module\URLStructure\Container; class Plugin extends Container { public function mameiwsayuyquoeq() { Yoast::symcgieuakksimmu(); Woocommerce::symcgieuakksimmu(); } }
