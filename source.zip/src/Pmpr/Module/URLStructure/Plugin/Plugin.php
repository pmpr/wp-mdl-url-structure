<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8c4c11cb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; use Pmpr\Module\URLStructure\Container; class Plugin extends Container { public function mameiwsayuyquoeq() { Yoast::symcgieuakksimmu(); Woocommerce::symcgieuakksimmu(); } }
