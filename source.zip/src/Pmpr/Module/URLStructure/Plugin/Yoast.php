<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b24827aec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; class Yoast extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x70\163\145\157\137\163\x69\x74\x65\155\x61\x70\x5f\145\x6e\x74\162\x79", [$this, "\145\x75\155\x73\165\x6b\x75\151\163\x67\165\x61\x6d\x6f\x75\x63"], 10, 3)->cecaguuoecmccuse("\x77\160\163\145\x6f\x5f\170\155\154\x5f\x73\151\x74\145\x6d\141\160\137\160\x6f\x73\164\x5f\165\x72\x6c", [$this, "\155\157\161\x6f\145\157\x75\x79\143\161\x75\153\x79\x6d\145\157"], 10, 2); } public function wegiiamywoyckysa($eeamcawaiqocomwy, $ymysywcqikkiqocw, $post) { if (!(self::mswoacegomcucaik === $ymysywcqikkiqocw && isset($eeamcawaiqocomwy["\154\157\143"]))) { goto eyiamcekkgkiawqy; } $eeamcawaiqocomwy["\154\x6f\143"] = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ycqquoiyyuesegsy($post); eyiamcekkgkiawqy: return $eeamcawaiqocomwy; } public function moqoeouycqukymeo($migiiksoiymissge, $post) { return $this->ocksiywmkyaqseou(self::uisisakqmumqggsg . "\x67\145\x74\x5f\x70\x6f\x73\x74\x5f\165\x6e\x63\x68\x61\x6e\x67\145\x64\137\154\151\x6e\153", $migiiksoiymissge, $post); } }
