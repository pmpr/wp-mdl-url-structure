<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4263da423             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; class Yoast extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x70\163\145\157\x5f\163\151\x74\145\155\x61\160\137\145\x6e\x74\x72\x79", [$this, "\145\165\x6d\163\165\x6b\x75\151\x73\x67\165\141\155\x6f\x75\143"], 10, 3)->cecaguuoecmccuse("\x77\160\x73\145\157\137\170\155\154\137\163\151\164\x65\x6d\x61\x70\137\x70\157\x73\164\x5f\165\162\154", [$this, "\x6d\157\161\x6f\x65\x6f\165\171\143\x71\165\x6b\x79\x6d\x65\157"], 10, 2); } public function wegiiamywoyckysa($eeamcawaiqocomwy, $ymysywcqikkiqocw, $post) { if (!(self::mswoacegomcucaik === $ymysywcqikkiqocw && isset($eeamcawaiqocomwy["\154\157\143"]))) { goto usqgaogkqgemuima; } $eeamcawaiqocomwy["\154\x6f\x63"] = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ycqquoiyyuesegsy($post); usqgaogkqgemuima: return $eeamcawaiqocomwy; } public function moqoeouycqukymeo($migiiksoiymissge, $post) { return $this->ocksiywmkyaqseou(self::uisisakqmumqggsg . "\147\145\164\137\160\157\x73\164\137\165\x6e\143\150\x61\x6e\x67\145\x64\x5f\154\x69\x6e\x6b", $migiiksoiymissge, $post); } }
