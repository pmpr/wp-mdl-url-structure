<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012e98929             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; class Yoast extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x70\163\x65\x6f\x5f\163\x69\x74\x65\x6d\141\160\137\x65\x6e\x74\162\x79", [$this, "\145\165\155\163\165\153\x75\151\x73\x67\165\141\155\157\165\x63"], 10, 3)->cecaguuoecmccuse("\x77\x70\x73\145\157\137\x78\x6d\154\x5f\163\151\164\x65\155\141\160\137\160\x6f\163\x74\x5f\165\x72\x6c", [$this, "\155\157\161\157\x65\x6f\165\x79\x63\x71\x75\x6b\x79\155\145\x6f"], 10, 2); } public function wegiiamywoyckysa($eeamcawaiqocomwy, $ymysywcqikkiqocw, $post) { if (!(self::mswoacegomcucaik === $ymysywcqikkiqocw && isset($eeamcawaiqocomwy["\x6c\x6f\143"]))) { goto goeoymmqqqeeoime; } $eeamcawaiqocomwy["\x6c\x6f\143"] = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ycqquoiyyuesegsy($post); goeoymmqqqeeoime: return $eeamcawaiqocomwy; } public function moqoeouycqukymeo($migiiksoiymissge, $post) { return $this->ocksiywmkyaqseou(self::uisisakqmumqggsg . "\147\x65\164\x5f\160\x6f\163\164\x5f\165\156\143\150\x61\156\x67\x65\144\x5f\154\151\156\x6b", $migiiksoiymissge, $post); } }
