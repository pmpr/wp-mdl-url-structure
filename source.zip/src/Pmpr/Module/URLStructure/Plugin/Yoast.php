<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708633897f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; class Yoast extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\160\163\x65\x6f\x5f\x73\151\164\145\x6d\x61\160\x5f\145\x6e\164\x72\x79", [$this, "\145\165\155\163\165\x6b\x75\151\163\147\x75\141\x6d\x6f\165\143"], 10, 3)->cecaguuoecmccuse("\x77\x70\163\145\157\137\170\x6d\x6c\x5f\163\151\164\145\155\141\160\137\x70\x6f\163\x74\x5f\x75\x72\154", [$this, "\155\x6f\161\x6f\x65\157\165\171\x63\x71\165\x6b\x79\155\145\x6f"], 10, 2); } public function wegiiamywoyckysa($eeamcawaiqocomwy, $ymysywcqikkiqocw, $post) { if (!(self::mswoacegomcucaik === $ymysywcqikkiqocw && isset($eeamcawaiqocomwy["\154\x6f\143"]))) { goto goeoymmqqqeeoime; } $eeamcawaiqocomwy["\x6c\x6f\143"] = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ycqquoiyyuesegsy($post); goeoymmqqqeeoime: return $eeamcawaiqocomwy; } public function moqoeouycqukymeo($migiiksoiymissge, $post) { return $this->ocksiywmkyaqseou(self::uisisakqmumqggsg . "\x67\145\x74\137\x70\157\x73\x74\x5f\x75\x6e\143\x68\x61\156\x67\x65\144\x5f\154\x69\x6e\153", $migiiksoiymissge, $post); } }
