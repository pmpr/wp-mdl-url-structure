<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8d5ac0b6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; class Yoast extends Common { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\160\x73\145\x6f\137\163\151\x74\145\155\x61\x70\x5f\145\x6e\x74\x72\x79", [$this, "\145\165\x6d\x73\x75\153\165\x69\x73\x67\x75\x61\x6d\x6f\x75\143"], 10, 3)->cecaguuoecmccuse("\167\x70\163\145\157\x5f\170\155\154\x5f\x73\x69\164\145\155\141\x70\x5f\x70\157\x73\164\137\165\x72\x6c", [$this, "\155\157\x71\x6f\145\x6f\165\171\143\161\165\153\171\x6d\145\157"], 10, 2); } public function wegiiamywoyckysa($eeamcawaiqocomwy, $ymysywcqikkiqocw, $post) { if (!(self::mswoacegomcucaik === $ymysywcqikkiqocw && isset($eeamcawaiqocomwy["\x6c\x6f\x63"]))) { goto cuoqqgaygogsmmic; } $eeamcawaiqocomwy["\x6c\157\143"] = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ycqquoiyyuesegsy($post); cuoqqgaygogsmmic: return $eeamcawaiqocomwy; } public function moqoeouycqukymeo($migiiksoiymissge, $post) { return $this->ocksiywmkyaqseou(self::uisisakqmumqggsg . "\x67\x65\x74\x5f\160\157\163\164\x5f\165\x6e\x63\x68\141\156\x67\x65\144\137\x6c\151\156\153", $migiiksoiymissge, $post); } }
