<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012e98929             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; class Woocommerce extends Common { }
