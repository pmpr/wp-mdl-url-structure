<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68daeb7a21c5a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; use Pmpr\Module\URLStructure\Container; class Woocommerce extends Container { }
