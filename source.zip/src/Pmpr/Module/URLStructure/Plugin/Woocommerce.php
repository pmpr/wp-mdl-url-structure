<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8c4c11cb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Plugin; class Woocommerce extends Common { }
