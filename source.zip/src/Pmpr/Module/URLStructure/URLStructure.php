<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b8323da2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\URLStructure\Plugin\Plugin; use Pmpr\Module\URLStructure\Plugin\Woocommerce; use Pmpr\Module\URLStructure\Plugin\Yoast; class URLStructure extends ComponentInitiator { const uisisakqmumqggsg = "\x75\x72\x6c\x5f\x73\x74\x72\x75\x63\164\x75\x72\x65\x5f"; public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\125\122\114\40\123\x74\162\165\143\x74\165\162\145", PR__MDL__URL_STRUCTURE); }, Constants::wuowaiyouwecckaw => false, Constants::sguyaymiiiiewame => Setting::class]); } public function mameiwsayuyquoeq() { Hook::symcgieuakksimmu(); Rewrite::symcgieuakksimmu(); Yoast::symcgieuakksimmu(); } }
