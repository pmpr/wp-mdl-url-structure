<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708633897f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\URLStructure\Plugin\Plugin; class URLStructure extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\125\x52\x4c\x20\x53\x74\x72\165\x63\164\x75\162\x65", PR__MDL__URL_STRUCTURE); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Hook::symcgieuakksimmu(); Plugin::symcgieuakksimmu(); Rewrite::symcgieuakksimmu(); Setting::symcgieuakksimmu(); } }
