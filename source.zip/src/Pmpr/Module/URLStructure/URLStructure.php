<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8c4c11cb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\URLStructure\Plugin\Plugin; class URLStructure extends ComponentInitiator { const uisisakqmumqggsg = "\x75\162\154\137\x73\164\162\165\143\x74\x75\x72\x65\137"; public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\125\122\x4c\x20\123\164\x72\165\x63\x74\x75\162\145", PR__MDL__URL_STRUCTURE); }, Constants::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Hook::symcgieuakksimmu(); Plugin::symcgieuakksimmu(); Rewrite::symcgieuakksimmu(); Setting::symcgieuakksimmu(); } }
