<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012e98929             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\URLStructure\Plugin\Plugin; class URLStructure extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\125\122\x4c\x20\x53\164\162\x75\x63\164\x75\x72\145", PR__MDL__URL_STRUCTURE); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Hook::symcgieuakksimmu(); Plugin::symcgieuakksimmu(); Rewrite::symcgieuakksimmu(); Setting::symcgieuakksimmu(); } }
