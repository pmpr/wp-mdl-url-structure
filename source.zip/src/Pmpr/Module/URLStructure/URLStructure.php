<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11e9e8858             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\URLStructure\Plugin\Plugin; class URLStructure extends ComponentInitiator { const uisisakqmumqggsg = "\x75\162\x6c\137\163\x74\x72\x75\143\x74\x75\162\x65\137"; public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\x55\122\114\x20\123\x74\162\165\143\164\165\x72\x65", PR__MDL__URL_STRUCTURE); }, Constants::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { Hook::symcgieuakksimmu(); Plugin::symcgieuakksimmu(); Rewrite::symcgieuakksimmu(); Setting::symcgieuakksimmu(); } }
