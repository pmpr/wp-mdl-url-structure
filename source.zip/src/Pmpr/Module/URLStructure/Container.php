<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11e9e8858             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
