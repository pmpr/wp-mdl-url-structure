<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708633897f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\URLStructure\Interfaces\CommonInterface; use Pmpr\Module\URLStructure\Traits\EngineTrait; abstract class Container extends BaseClass implements CommonInterface { use EngineTrait; public function ikcgmcycisiccyuc() { $this->settingObj = Setting::symcgieuakksimmu(); } }
