<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8d5ac0b6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Interfaces; interface CommonInterface { const ceaiocqyiommcosc = "\163\x75\142\144\x6f\x6d\x61\151\x6e"; const skiciycymuceasgc = self::ceaiocqyiommcosc . "\x5f"; const qiiewisegcemqoig = "\x75\x72\154\137\163\164\162\165\143\x74\x75\162\145"; const uisisakqmumqggsg = self::qiiewisegcemqoig . "\x5f"; const wuaiimymycguougc = "\x70\x6f\x73\164\137\x73\x6c\x75\x67"; const qiyqieuuecggmycc = "\164\x65\x72\155\x5f\x73\154\x75\x67"; const uoaamagqugwgkski = "\x70\157\163\164\x5f\x74\x79\160\145\137\163\x6c\x75\147"; }
