<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b24827aec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Interfaces; interface CommonInterface { const ceaiocqyiommcosc = "\163\165\x62\144\157\x6d\x61\151\156"; const skiciycymuceasgc = self::ceaiocqyiommcosc . "\137"; const qiiewisegcemqoig = "\165\x72\x6c\137\163\164\x72\x75\x63\164\x75\162\145"; const uisisakqmumqggsg = self::qiiewisegcemqoig . "\137"; const wuaiimymycguougc = "\160\157\163\x74\x5f\x73\x6c\165\x67"; const qiyqieuuecggmycc = "\164\x65\162\x6d\137\x73\154\x75\x67"; const uoaamagqugwgkski = "\160\157\x73\164\137\x74\x79\x70\145\137\x73\x6c\x75\x67"; }
