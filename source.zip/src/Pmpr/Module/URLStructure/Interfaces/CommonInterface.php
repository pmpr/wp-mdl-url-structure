<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668708633897f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Interfaces; interface CommonInterface { const ceaiocqyiommcosc = "\x73\x75\x62\144\157\x6d\x61\151\x6e"; const skiciycymuceasgc = self::ceaiocqyiommcosc . "\137"; const qiiewisegcemqoig = "\165\x72\x6c\x5f\x73\164\162\x75\143\164\165\162\x65"; const uisisakqmumqggsg = self::qiiewisegcemqoig . "\137"; const wuaiimymycguougc = "\x70\x6f\x73\x74\137\x73\154\x75\x67"; const qiyqieuuecggmycc = "\x74\145\x72\155\137\163\154\165\147"; const uoaamagqugwgkski = "\160\157\163\x74\x5f\x74\x79\x70\x65\137\x73\x6c\165\x67"; }
