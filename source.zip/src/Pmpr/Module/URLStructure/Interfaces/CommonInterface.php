<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012e98929             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Interfaces; interface CommonInterface { const ceaiocqyiommcosc = "\x73\x75\x62\x64\157\155\141\x69\x6e"; const skiciycymuceasgc = self::ceaiocqyiommcosc . "\x5f"; const qiiewisegcemqoig = "\165\162\x6c\137\163\x74\x72\x75\x63\x74\x75\x72\145"; const uisisakqmumqggsg = self::qiiewisegcemqoig . "\x5f"; const wuaiimymycguougc = "\x70\x6f\x73\164\x5f\163\x6c\x75\147"; const qiyqieuuecggmycc = "\164\x65\162\155\137\x73\x6c\x75\x67"; const uoaamagqugwgkski = "\x70\x6f\163\164\137\x74\171\160\x65\137\163\154\x75\147"; }
