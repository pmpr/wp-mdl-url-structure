<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e4263da423             |
    |_______________________________________|
*/
 namespace Pmpr\Module\URLStructure\Interfaces; interface CommonInterface { const ceaiocqyiommcosc = "\163\x75\142\144\157\155\x61\x69\x6e"; const skiciycymuceasgc = self::ceaiocqyiommcosc . "\x5f"; const qiiewisegcemqoig = "\165\x72\x6c\137\x73\164\x72\165\x63\164\x75\162\145"; const uisisakqmumqggsg = self::qiiewisegcemqoig . "\x5f"; const wuaiimymycguougc = "\160\157\163\164\x5f\x73\x6c\x75\x67"; const qiyqieuuecggmycc = "\164\x65\162\x6d\x5f\163\x6c\165\x67"; const uoaamagqugwgkski = "\x70\157\x73\x74\137\164\171\160\145\x5f\x73\154\x75\147"; }
